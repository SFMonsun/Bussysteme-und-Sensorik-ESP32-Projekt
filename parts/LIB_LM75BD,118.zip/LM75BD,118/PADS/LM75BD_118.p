*PADS-LIBRARY-PART-TYPES-V9*

LM75BD_118 SOIC127P600X175-8N I ANA 7 1 0 0 0
TIMESTAMP 2025.10.17.07.50.13
"Mouser Part Number" 771-LM75BD118
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/NXP-Semiconductors/LM75BD118?qs=tKEQ0l%252B78Dle%2FKEoz9Gpmw%3D%3D
"Manufacturer_Name" NXP
"Manufacturer_Part_Number" LM75BD,118
"Description" NXP - LM75BD,118 - TEMPERATURE SENSOR, OPEN DRAIN, SOIC-8
"Datasheet Link" http://www.nxp.com/docs/en/data-sheet/LM75B.pdf
"Geometry.Height" 1.75mm
GATE 1 8 0
LM75BD_118
1 0 U SDA
2 0 U SCL
3 0 U OS
4 0 U GND
8 0 U VCC
7 0 U A0
6 0 U A1
5 0 U A2

*END*
*REMARK* SamacSys ECAD Model
1103523/1771769/2.50/8/3/Integrated Circuit
