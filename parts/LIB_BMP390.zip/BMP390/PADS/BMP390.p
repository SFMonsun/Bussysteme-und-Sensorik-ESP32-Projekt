*PADS-LIBRARY-PART-TYPES-V9*

BMP390 BMP390 I ANA 7 1 0 0 0
TIMESTAMP 2025.10.17.07.30.44
"Mouser Part Number" 262-BMP390
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Bosch-Sensortec/BMP390?qs=QNEnbhJQKvYQVfvRMgo2YA%3D%3D
"Manufacturer_Name" BOSCH
"Manufacturer_Part_Number" BMP390
"Description" Board Mount Pressure Sensors
"Datasheet Link" https://www.bosch-sensortec.com/media/boschsensortec/downloads/datasheets/bst-bmp390-ds002.pdf
"Geometry.Height" 0.8mm
GATE 1 10 0
BMP390
1 0 U VDDIO
2 0 U SCK
3 0 U VSS_1
4 0 U SDI
5 0 U SDO
6 0 U CSB
7 0 U INT
8 0 U VSS_2
9 0 U VSS_3
10 0 U VDD

*END*
*REMARK* SamacSys ECAD Model
13229313/1771769/2.50/10/4/Integrated Circuit
